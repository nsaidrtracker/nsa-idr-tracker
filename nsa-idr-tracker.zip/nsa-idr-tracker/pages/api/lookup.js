export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({error: 'Method not allowed'})

  const { abbr, stateName } = req.body
  if (!abbr || !stateName) return res.status(400).json({error: 'Missing state'})

  const prompt = `You are an expert in the federal No Surprises Act (NSA) and Independent Dispute Resolution (IDR) laws. Use web search to find the most current, accurate information about ${stateName}'s surprise billing and IDR laws as of today.

Return ONLY a valid JSON object with no markdown, no backticks, no extra text. Use this exact structure:
{
  "status": "federal" or "state" or "bifurcated",
  "effectiveDate": "string describing when the law took effect",
  "summary": "2-3 sentence plain English summary of current law status",
  "keyRules": ["rule 1", "rule 2", "rule 3"],
  "recentChanges": "Any notable updates or changes in the past 1-2 years, or 'No major recent changes reported.'",
  "whoItAffects": "Brief note on how this affects providers vs payers vs patients",
  "sourceUrl": "most relevant official URL (CMS, state DOI, or state legislature)"
}`

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        tools: [{type: 'web_search_20250305', name: 'web_search'}],
        messages: [{role: 'user', content: prompt}]
      })
    })

    const data = await response.json()
    let resultText = ''
    for (const block of data.content) {
      if (block.type === 'text') resultText += block.text
    }

    resultText = resultText.replace(/```json|```/g, '').trim()
    const parsed = JSON.parse(resultText)
    return res.status(200).json(parsed)
  } catch (e) {
    console.error('Lookup error:', e)
    return res.status(500).json({error: 'Lookup failed'})
  }
}
