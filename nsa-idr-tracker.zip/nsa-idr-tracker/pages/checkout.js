import Head from 'next/head'
import Link from 'next/link'
import { useRouter } from 'next/router'
import { useState, useEffect } from 'react'

const baseData = {
  AL:"Alabama",AK:"Alaska",AZ:"Arizona",AR:"Arkansas",CA:"California",CO:"Colorado",
  CT:"Connecticut",DE:"Delaware",FL:"Florida",GA:"Georgia",HI:"Hawaii",ID:"Idaho",
  IL:"Illinois",IN:"Indiana",IA:"Iowa",KS:"Kansas",KY:"Kentucky",LA:"Louisiana",
  ME:"Maine",MD:"Maryland",MA:"Massachusetts",MI:"Michigan",MN:"Minnesota",
  MS:"Mississippi",MO:"Missouri",MT:"Montana",NE:"Nebraska",NV:"Nevada",
  NH:"New Hampshire",NJ:"New Jersey",NM:"New Mexico",NY:"New York",
  NC:"North Carolina",ND:"North Dakota",OH:"Ohio",OK:"Oklahoma",OR:"Oregon",
  PA:"Pennsylvania",RI:"Rhode Island",SC:"South Carolina",SD:"South Dakota",
  TN:"Tennessee",TX:"Texas",UT:"Utah",VT:"Vermont",VA:"Virginia",
  WA:"Washington",WV:"West Virginia",WI:"Wisconsin",WY:"Wyoming"
}

const PLANS = {
  single:  {label:'Single state lookup',price:'$9.99',desc:'One state, one time',color:'#64748B'},
  monthly: {label:'Monthly subscription',price:'$79/mo',desc:'All 50 states, unlimited lookups',color:'#1B4FD8'},
  annual:  {label:'Annual subscription',price:'$749/yr',desc:'All 50 states, save $199',color:'#7C3AED'},
  team:    {label:'Team plan',price:'$299/mo',desc:'Up to 10 users',color:'#059669'},
}

export default function Checkout() {
  const router = useRouter()
  const { plan } = router.query
  const [selectedState, setSelectedState] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const planInfo = PLANS[plan]

  async function handleCheckout() {
    if (plan === 'single' && !selectedState) {
      setError('Please select a state before continuing.')
      return
    }
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({plan, selectedState: plan === 'single' ? selectedState : ''})
      })
      const data = await res.json()
      if (data.url) {
        window.location.href = data.url
      } else {
        setError('Something went wrong. Please try again.')
        setLoading(false)
      }
    } catch(e) {
      setError('Something went wrong. Please try again.')
      setLoading(false)
    }
  }

  if (!plan || !planInfo) return (
    <div style={{padding:40,textAlign:'center',fontFamily:'Inter,sans-serif'}}>
      <p>Invalid plan. <Link href="/#pricing" style={{color:'#1B4FD8'}}>See pricing</Link></p>
    </div>
  )

  return (
    <>
      <Head>
        <title>Checkout — NSA/IDR Tracker</title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@2.44.0/tabler-icons.min.css" />
      </Head>
      <div style={{minHeight:'100vh',background:'#F8FAFC',fontFamily:'Inter,sans-serif',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:24}}>

        <div style={{width:'100%',maxWidth:480,background:'#fff',border:'1px solid #E2E8F0',borderRadius:16,padding:36}}>

          <Link href="/" style={{display:'flex',alignItems:'center',gap:8,marginBottom:28}}>
            <div style={{width:28,height:28,background:'#1B4FD8',borderRadius:6,display:'flex',alignItems:'center',justifyContent:'center'}}>
              <i className="ti ti-map-2" style={{color:'#fff',fontSize:15}}></i>
            </div>
            <span style={{fontWeight:700,fontSize:14,color:'#0F172A'}}>NSA/IDR Tracker</span>
          </Link>

          <h1 style={{fontSize:22,fontWeight:700,color:'#0F172A',marginBottom:4}}>Complete your purchase</h1>
          <p style={{fontSize:14,color:'#64748B',marginBottom:24}}>You'll be redirected to Stripe's secure checkout.</p>

          {/* Plan summary */}
          <div style={{background:'#F8FAFC',border:'1px solid #E2E8F0',borderRadius:10,padding:'14px 16px',marginBottom:24}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <div>
                <div style={{fontWeight:600,fontSize:14,color:'#0F172A'}}>{planInfo.label}</div>
                <div style={{fontSize:12,color:'#64748B',marginTop:2}}>{planInfo.desc}</div>
              </div>
              <div style={{fontWeight:700,fontSize:18,color:planInfo.color}}>{planInfo.price}</div>
            </div>
          </div>

          {/* State selector for single plan */}
          {plan === 'single' && (
            <div style={{marginBottom:20}}>
              <label style={{fontSize:13,fontWeight:600,color:'#0F172A',display:'block',marginBottom:6}}>
                Select your state <span style={{color:'#DC2626'}}>*</span>
              </label>
              <select value={selectedState} onChange={e=>setSelectedState(e.target.value)}
                style={{width:'100%',padding:'10px 12px',border:'1px solid #E2E8F0',borderRadius:8,fontSize:14,color:'#0F172A',background:'#fff',outline:'none'}}>
                <option value="">Choose a state…</option>
                {Object.entries(baseData).sort((a,b)=>a[1].localeCompare(b[1])).map(([abbr,name])=>(
                  <option key={abbr} value={abbr}>{name}</option>
                ))}
              </select>
              <p style={{fontSize:12,color:'#94A3B8',marginTop:6}}>
                <i className="ti ti-info-circle" style={{fontSize:12}}></i> Your lookup is locked to this state. Choose carefully.
              </p>
            </div>
          )}

          {error && (
            <div style={{background:'#FEF2F2',border:'1px solid #FECACA',borderRadius:8,padding:'10px 14px',fontSize:13,color:'#DC2626',marginBottom:16}}>
              {error}
            </div>
          )}

          <button onClick={handleCheckout} disabled={loading}
            style={{width:'100%',background:loading?'#93C5FD':'#1B4FD8',color:'#fff',padding:'13px',borderRadius:9,fontSize:15,fontWeight:600,border:'none',cursor:loading?'not-allowed':'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:8,marginBottom:14}}>
            {loading
              ? <><span style={{width:16,height:16,border:'2px solid rgba(255,255,255,0.4)',borderTopColor:'#fff',borderRadius:'50%',display:'inline-block',animation:'spin 0.7s linear infinite'}}></span> Redirecting…</>
              : <><i className="ti ti-lock"></i> Continue to secure checkout</>
            }
          </button>

          <p style={{fontSize:12,color:'#94A3B8',textAlign:'center'}}>
            <i className="ti ti-shield-check" style={{fontSize:12}}></i> Secured by Stripe. We never store your card details.
          </p>

          <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
        </div>

        <p style={{fontSize:12,color:'#94A3B8',marginTop:16}}>
          <Link href="/#pricing" style={{color:'#64748B'}}>← Back to pricing</Link>
        </p>
      </div>
    </>
  )
}
