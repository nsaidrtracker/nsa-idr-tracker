# NSA/IDR Tracker — Setup Guide

## What you have
A full web app with:
- Landing page with pricing
- Interactive US map tracker
- Live AI-powered state lookups (Anthropic API + web search)
- Stripe payment integration (single use, monthly, annual, team)
- Single-use guardrail (locks to one state after purchase)

---

## Step 1 — Get your API keys

### Anthropic (for the AI lookups)
1. Go to https://console.anthropic.com
2. Click "API Keys" → "Create Key"
3. Copy the key (starts with `sk-ant-`)

### Stripe (for payments)
1. Go to https://dashboard.stripe.com
2. Sign up for a free account
3. Go to Developers → API Keys
4. Copy your "Publishable key" and "Secret key"

### Create Stripe Products
In Stripe Dashboard → Products → Add Product:
- **Single state lookup** — $9.99, one-time payment
- **Monthly plan** — $79.00/month, recurring
- **Annual plan** — $749.00/year, recurring
- **Team plan** — $299.00/month, recurring

After creating each, copy the **Price ID** (starts with `price_`)

---

## Step 2 — Deploy to Vercel

1. Go to https://vercel.com and sign in with GitHub
2. Click "Add New Project"
3. Upload this folder or connect your GitHub repo
4. Add these Environment Variables in the Vercel dashboard:

```
ANTHROPIC_API_KEY=sk-ant-your-key
STRIPE_SECRET_KEY=sk_live_your-key
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_your-key
STRIPE_PRICE_SINGLE=price_xxxxx
STRIPE_PRICE_MONTHLY=price_xxxxx
STRIPE_PRICE_ANNUAL=price_xxxxx
STRIPE_PRICE_TEAM=price_xxxxx
NEXT_PUBLIC_SITE_URL=https://your-app.vercel.app
```

5. Click Deploy — Vercel handles everything automatically

---

## Step 3 — Set up Stripe Webhook (for subscription management)

1. In Stripe Dashboard → Developers → Webhooks
2. Add endpoint: `https://your-app.vercel.app/api/webhook`
3. Select events: `checkout.session.completed`, `customer.subscription.deleted`
4. Copy the webhook signing secret
5. Add to Vercel env vars: `STRIPE_WEBHOOK_SECRET=whsec_xxxxx`

---

## Step 4 — Get a domain (optional but recommended)

1. Buy a domain at Namecheap or Google Domains (~$12/year)
   Suggestions: `nsaidrtracker.com`, `idrstatemap.com`, `surprisebillingtracker.com`
2. In Vercel → your project → Settings → Domains → Add your domain
3. Follow Vercel's instructions to point your domain

---

## You're live! 🎉

Your app will be at `https://your-domain.com` with:
- Public landing page
- Free map view (colors only, no AI details)
- Paid AI lookups via Stripe checkout
- Single-use state lock enforced automatically
